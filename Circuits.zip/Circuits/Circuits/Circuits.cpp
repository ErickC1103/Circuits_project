#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	// This program creates a Table of Values depending on the values inputted by the user.
	// The program calculates V1, V2, V3, Rt, I, and P for a VDC Series Circuit with (3) Resistors Using Ohm's law
	float Vt;// stores value of the total voltage
	float R1;// stores value for the first resistor
	float R2;// store value for the second resistor
	float R3;// stores value for the third resistor
	cout << "this program will calculate V1, V2, V3, Rt, I, and P for a VDC Series Circuit with (3) Resistors" << endl;
	cout << "the information will be placed in a table below" << endl;
	cout << "type in the DC voltage source (V) rounded to the nearest whole number" << endl;	
	cin >> Vt;// allows the user to input the total voltage
	cout << "type in the value of each resistor seperated by tabs or <ENTER>." << endl;
	cin >> R1;// allows the user to input the first resistor
	cin >> R2;// allows the user to input the second resistor
	cin >> R3;// allows the user to input the third resistor
	float Rt = R1 + R2 + R3;//combines all the resistors into a new value
	float I = Vt / Rt ;// uses ohm's law to calculate the current using the total voltage and total resistance
	float V1 = I * R1;// uses ohms law to calculate the voltage when it passes the first resistor
	float V2 = I * R2;// uses ohms law to calculate the voltage when it passes the second resistor
	float V3 = I * R3;// uses ohms law to calculate the voltage when it passes the third resistor
	float P = Vt * I;// uses ohms law to calculate Power
	cout << endl;
	cout << "using cout" << endl;
	cout << "Values\t\t\t|R1\t\t\t|R2\t\t\t|R3\t\t\t|Total" << endl;// Title row
	cout << fixed << setprecision(1) << "Resistors\t\t|"  << R1 << "\t\t\t|" << R2 << "\t\t\t|" << R3 << "\t\t\t|" << setprecision(3) << Rt << endl;
	// ^this row displays the values of all resistors and total resistors
	cout << fixed << setprecision(3) << "Voltages\t\t|" << V1 << "\t\t\t|" << V2 << "\t\t\t|" << V3 << "\t\t\t|" << setprecision(0) << Vt << endl;
	//^this row displays the values of all voltages and the total voltage
	cout << fixed << setprecision(3) << "Current\t\t\t|\t\t\t|\t\t\t|\t\t\t|" << I << endl;
	//^this row displays the value of the current
	cout << fixed << setprecision(3) << "Power\t\t\t|\t\t\t|\t\t\t|\t\t\t|" << P << endl;
	//^this row displays the value of power
}